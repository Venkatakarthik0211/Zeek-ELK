import json
import nltk
import boto3
import os
from nltk.tokenize import word_tokenize
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

# Set the NLTK data path
nltk.data.path.append('/opt/nltk_data')

# Initialize S3 client with environment variables
s3bucket = os.getenv('S3_BUCKET')
s3file = os.getenv('S3_FILE')

s3 = boto3.client('s3')

def handler(event, context):
    try:
        data = s3.get_object(Bucket=s3bucket, Key=s3file)
        file_content = data['Body'].read().decode('utf-8')
        words = word_tokenize(file_content)
        return {
            'statusCode': 200,
            'body': json.dumps(words)
        }
    except NoCredentialsError:
        return {
            'statusCode': 500,
            'body': json.dumps('No AWS credentials found')
        }
    except PartialCredentialsError:
        return {
            'statusCode': 500,
            'body': json.dumps('Partial AWS credentials found')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(str(e))
        }
